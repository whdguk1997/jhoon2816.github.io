
module.exports = {
	server_port: 3000,
	db_url: 'mongodb://localhost:27017/local',
	db_schemas: [
	    {file:'./user_schema', /*collection:'user5'*/collection:'users6', schemaName:'UserSchema', modelName:'UserModel'}
	],
	route_info: [
	],
	facebook : {
		clientID: '2226809220868868',
		clientSecret: '55f783814ce97e42e52245d31dea8e58',
		callbackURL: '/auth/facebook/callback'
	}
}