
const express = require('express');
const path = require('path');
const http = require('http');

const bodyParser = require('body-parser');
const static = require('serve-static');

const app = express();

//서버 구동 환경을 설정해주는 메소드 set('이름', 서버포트번호)
app.set('port', process.env.PORT|| 3000);

// bodyparser 라는 미들웨어가 url encoded 읽어들임.
app.use(bodyParser.urlencoded({extended:false}));

// bodyparser json파일을 읽어들임.
app.use(bodyParser.json());

//경로 localhost:3000/index.html --> localhost:3000/public/index.html
app.use('/public',static(path.join(__dirname, 'public')));

//미들웨어 구동 시작!
app.use( function(req,res){
   console.log('미들웨어가 실행되었습니다.');

    const paramId = req.body.id //|| res.query.id;
    const paramPassword = req.body.password //|| res.query.password;

    res.writeHead('200',{'Content-Type':'text/html;charset=utf8'});
    res.write('<p> HTML이 실행되었습니다.</p>');
    res.write('<div><p>ParamId :' + paramId + '</p></div>');
    res.write('<div><p>ParamPassword :' + paramPassword + '</p></div>');
    res.end();
});

http.createServer(app).listen(app.get('port'), function(){
    console.log('Express 서버 시작!' + app.get('port'));
});



