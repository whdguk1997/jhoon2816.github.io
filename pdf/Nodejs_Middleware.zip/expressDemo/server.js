var http = require('http');



app.createServer(function (req,res){
    console.log()
})