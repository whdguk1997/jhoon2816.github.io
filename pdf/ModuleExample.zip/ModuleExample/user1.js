exports.getUser = function () {
    return {id : 'test01', name : '소녀시대'};
}

exports.group = {id : 'group01', name : '친구'};