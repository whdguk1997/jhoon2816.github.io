exports.printUser = function () {
    console.log('user의 이름은 소녀시대입니다.')
};

