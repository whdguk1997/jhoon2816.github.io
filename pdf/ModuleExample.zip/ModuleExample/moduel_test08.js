var user = require('./user8');

user.printUser();