var User = require('./user10');
var user = new User('test01', '소녀시대');

user.printUser();