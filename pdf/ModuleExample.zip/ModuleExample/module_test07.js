var printUser = require('./user7').printUser;

printUser();