var user = {
    getUser : function () {
        return {id : 'test01', name : '소녀시대'};
    },
    group: {id : 'group1', name : '친구'}
}

module.exports = user;

