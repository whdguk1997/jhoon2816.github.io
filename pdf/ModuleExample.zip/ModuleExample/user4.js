module.exports = function () {
    return {id : 'test01', name : '소녀시대'};
};
