const express = require('express');
const router = express.Router();
const http = require('http');
const path = require('path');

const bodyParser = require('body-parser');
const static = require('serve-static');

const app = express();

// bodyparser 라는 미들웨어가 url encoded 읽어들임.
app.use(bodyParser.urlencoded({extended:false}));

// bodyparser json파일을 읽어들임.
app.use(bodyParser.json());

//서버 구동 환경을 설정해주는 메소드 set('이름', 서버포트번호)
app.set('port', process.env.PORT|| 3000);

//경로 설정
app.use('/public', static(path.join(__dirname, 'public')));

//미들웨어 구동 시작!
router.route('/process/login').post(function(req,res){
    console.log('/process/login 출력완료.');

    const paramId = req.body.id2 || req.query.id2;
    const paramPassword = req.body.password2 || req.query.password2;

    res.writeHead('200',{'Content-Type':'text/html;charset=utf8'});
    res.write('<p> HTML이 실행되었습니다.</p>');
    res.write('<div><p>ParamId :' + paramId + '</p></div>');
    res.write('<div><p>ParamPassword :' + paramPassword + '</p></div>');
    res.write('<br><br><a href="/public/login.html">로그인화면으로 돌아갑니다.</a>');
    res.end();
});
app.use('/',router);
//서버 구동
http.createServer(app).listen(app.get('port'), function(){
    console.log('Express 서버 시작!' + app.get('port'));
});